#! /bin/bash
exec java -jar ./standalone.jar

# Taken from https://stackoverflow.com/a/65520268/1457295
 
